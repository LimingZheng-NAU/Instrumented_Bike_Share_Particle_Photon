# Instrumented-bike
code for instrumented bike (Particle Photon)
1. Edit code for Particle Photon on online IDE.
2. Read data from accelerometers and Gobal Positioning System (GPS). 
3. Read data from multiple acclerometers through I2C interfaces.
3. The wireless communication of Particle photon to Mobile phones using TCP/IP protocol.
